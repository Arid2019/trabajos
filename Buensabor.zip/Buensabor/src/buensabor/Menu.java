/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package buensabor;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
         Scanner teclado = new Scanner(System.in); 
         
         String aparecerMenu;
         int Menu; 
         double descuento = 0, adicion = 0, total = 0;
         
         System.out.println("Desea el Menu? ( ingrese si o no) ");
         
         
         aparecerMenu = teclado.next();
         
         switch (aparecerMenu) {
             
             case"Si": case"SI": case"si":
                 
                 System.out.println("     Menu          Precio          adicion          Descuento     ");
                 
                 System.out.println("");
                 
                 System.out.println("1) bandeja paisa          25.000     Chicharron/Chorizo         10%");
                 System.out.println("2) mondongo          20.000     Ensalada/Aguacate         15%");
                 System.out.println("3) sancocho de cerdo          25.000      Ensalada/Aguacate         10%"); 
                 System.out.println("4) menu del dia          20.000      N/A         N/A%"); 
             
         
         
         }
         
         
    }
    
}
