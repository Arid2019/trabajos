/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buensabor;

import javax.swing.JOptionPane;
import java.util.Scanner;
 
public class Comidas {
    
    
    Scanner teclado = new Scanner(System.in); 
    
    
    
}
