/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso8;

import java.util.Scanner;

public class Caso8 {

    public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el precio total: $");
        double precio = sc.nextDouble();

        System.out.print("Ingrese el tipo de membresía (A, B o C): ");
        String membresia = sc.next().toUpperCase();

        double descuento = 0;

        switch (membresia) {

            case "A":
                descuento = 0.10;
                break;

            case "B":
                descuento = 0.15;
                break;

            case "C":
                descuento = 0.20;
                break;

            default:
                System.out.println("Membresía inválida");
                return;
        }

        double precioConDescuento = precio - (precio * descuento);

        if (precio > 100) {
            precioConDescuento = precioConDescuento -
                    (precioConDescuento * 0.05);
        }

        System.out.println("Precio original: $" + precio);
        System.out.println("Precio final: $" + precioConDescuento);
        
    }
    
}
