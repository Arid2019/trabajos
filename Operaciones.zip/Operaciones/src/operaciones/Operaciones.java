/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operaciones;

import java.util.Scanner;
public class Operaciones {

    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner (System.in);
        
        int numero1 = 0, numero2 = 0, resultado = 0;
        
        System.out.println(" ¿cual es tu nombre? ");
        
        String nombre = entrada.nextLine();
        
          System.out.print(" ingresa el primer numero a sumar");
          
          numero1 = entrada.nextInt();
          
          System.out.print(" ingresa el segundo numero");
          
           numero2 = entrada.nextInt();
           
           resultado = numero1 + numero2;
           
           System.out.println("hola" + nombre + "el resultado es:" + resultado ) ;
     
    }
    
}
