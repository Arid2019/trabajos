/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.promedio;

/**
 *
 * @author USUARIO
 */
public class Promedio {

    public static void main(String[] args) {

int numero1 = 5; 
int numero2 = 20;
int numero3 = 50;
int resultado = 0;

resultado = (numero2 + numero1 + numero3);

resultado = (numero2 + numero1 + numero3);
        System.out.println("El resultado de la suma de los 3 numeros es" + resultado);
    }
}


