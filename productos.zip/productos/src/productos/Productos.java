/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package productos;

/**
 *
 * @author USUARIO
 */
public class Productos {

         String codigo;
         String nombre;
         double precio;

    public Productos(String codigo, String nombre, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }
         
         
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
