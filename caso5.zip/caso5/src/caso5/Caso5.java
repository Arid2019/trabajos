/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso5;

import java.util.Scanner;

public class Caso5 {
   
    public static void main(String[] args) {
   
        Scanner entrada = new Scanner(System.in);

        double numero1, numero2, resultado;
        int opcion;

        System.out.print("Ingresa el primer número: ");
        numero1 = entrada.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        numero2 = entrada.nextDouble();

        System.out.println("\n--- CALCULADORA ---");
        System.out.println("1. Sumar");
        System.out.println("2. Restar");
        System.out.println("3. Multiplicar");
        System.out.println("4. Dividir");

        System.out.print("Elige una opción: ");
        opcion = entrada.nextInt();

        switch (opcion) {
            case 1:
                resultado = numero1 + numero2;
                System.out.println("Resultado: " + resultado);
                break;

            case 2:
                resultado = numero1 - numero2;
                System.out.println("Resultado: " + resultado);
                break;

            case 3:
                resultado = numero1 * numero2;
                System.out.println("Resultado: " + resultado);
                break;

            case 4:
                if (numero2 != 0) {
                    resultado = numero1 / numero2;
                    System.out.println("Resultado: " + resultado);
                } else {
                    System.out.println("No se puede dividir entre cero.");
                }
                break;

            default:
                System.out.println("Opción no válida.");
        }

        entrada.close();
    }
    
}
