/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package anidacion;


public class Anidacion {

    
    public static void main(String[] args) {
        
        int operacion = 1;
        int numero1 = 8;
        int numero2 = 4; 
        int resultado = 0; 
        
        if (operacion == 1){
            
            resultado = numero1 + numero2;
            System.out.println("el resultado de la suma es: " + resultado);
            
        }
        
        else if (operacion == 2) {
            resultado = numero1 * numero2;
            System.out.println("el resultado de la multiplicacion es: " + resultado);
        }   
       
    }
    
}
