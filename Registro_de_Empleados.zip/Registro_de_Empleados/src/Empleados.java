/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USUARIO
 */
public class Empleados {
  
    private String Nombre;
    private String Documento;
    private String Cargo;
    private String Area;
    private double Salario;
    private String FechaIngreso;

   
    public Empleados(String nombre, String documento,
                    String cargo, String area,
                    double salario, String fechaIngreso) {

        this.Nombre = nombre;
        this.Documento = documento;
        this.Cargo = cargo;
        this.Area = area;
        this.Salario = salario;
        this.FechaIngreso = fechaIngreso;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getDocumento() {
        return Documento;
    }

    public String getCargo() {
        return Cargo;
    }

    public String getArea() {
        return Area;
    }

    public double getSalario() {
        return Salario;
    }

    public String getFechaIngreso() {
        return FechaIngreso;
    }
}

    

