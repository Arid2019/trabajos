/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso10;

import java.util.Scanner;

public class Caso10 {

    
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);

        System.out.println("--- ESTACIONAMIENTO ---");
        System.out.println("1. Moto");
        System.out.println("2. Carro");
        System.out.println("3. Autobús");

        System.out.print("Seleccione el tipo de vehículo: ");
        int tipo = sc.nextInt();

        System.out.print("Ingrese las horas de estacionamiento: ");
        int horas = sc.nextInt();

        double tarifa = 0;

        switch (tipo) {

            case 1:
                tarifa = 2000;
                break;

            case 2:
                tarifa = 5000;
                break;

            case 3:
                tarifa = 8000;
                break;

            default:
                System.out.println("Tipo de vehículo inválido");
                return;
        }

        double total;

        if (horas > 8) {
            total = (tarifa * horas) * 0.90;
            System.out.println("Se aplicó un descuento del 10%.");
        } else {
            total = tarifa * horas;
        }

        System.out.println("Total a pagar: $" + total);
        
              
    }
    
}
