/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso3;

import java.util.Scanner;

public class Caso3 {

    public static void main(String[] args) {
    
                Scanner entrada = new Scanner(System.in);

        String claveGuardada = "12345";
        String claveIngresada;

        System.out.print("Ingresa la contraseña: ");
        claveIngresada = entrada.nextLine();

        if (claveIngresada.equals(claveGuardada)) {
            System.out.println("Bienvenido");
        } else {
            System.out.println("Contraseña incorrecta");
        }

        entrada.close();
        
        
    }
    
}
