/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ariadna;

/**
 *
 * @author USUARIO
 */
public class Ariadna {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int numero1 = 5;
      int numero2 = 10; 
      int resultado = 0; 
      int parametros = 5; 
      
      
      switch(parametros){ 
          
          case 1: resultado = numero1 + numero2;
        
        System.out.println("el resultado de la suma es:" + resultado); 
        break;
        
        case 2: resultado = numero1 * numero2;
        
        System.out.println("el resultado de la multiplicacion es:" + resultado);
        break; 
        
       case 3: resultado = numero1 - numero2;
        
        System.out.println("el resultado de la resta es:" + resultado);
        break;  
        
        case 4: resultado = numero1 / numero2;
        
        System.out.println("el resultado de la division es:" + resultado);
        break; 
        
        default: System.out.println("error, la opcion no existe");
        break; 
        
    }
    }
    
}
