/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso4;

import java.util.Scanner;

public class Caso4 {

    public static void main(String[] args) {
        
               Scanner entrada = new Scanner(System.in);

        int nota;

        System.out.print("Ingresa tu nota (1-100): ");
        nota = entrada.nextInt();

        if (nota >= 90) {
            System.out.println("Excelente");
        } else if (nota >= 70) {
            System.out.println("Aprobado");
        } else {
            System.out.println("Reprobado");
        }
        entrada.close();
  
    }
    
}
