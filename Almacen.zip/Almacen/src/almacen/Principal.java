/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package almacen;

/**
 *
 * @author USUARIO
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Producto producto1 = new Producto ("p001", "teclado", 80000);
        Producto producto2 = new Producto ("p002", "mouse", 40000);
        
        System.out.println("=== PRODUCTO 1 ===");
        
        producto1.mostrarInformacio();
        
        System.out.println("precio con descuento:" + producto1.calcularDescuento());
        
         System.out.println();
        
    } 
    
}
