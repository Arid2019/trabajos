/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package almacen;

/**
 *
 * @author USUARIO
 */
public class Producto {
    
    String codigo;
    String nombre; 
    double precio;

    public Producto(String codigo, String nombre, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    
    public void mostrarInformacio(){
    
    System.out.println("Codigo:" + codigo);
    System.out.println("Nombre:" + nombre);
    System.out.println("Precio:$ " + precio);
    
    }
    
        public double calcularDescuento(){
        
        return precio - (precio * 0.10);
        
        }    
             
            }


