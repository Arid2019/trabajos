/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package notas;

/**
 *
 * @author USUARIO
 */
public class Notas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int nota1 = 10;
        int nota2 = 7;
        int nota3 = 16;
        int resultado = 0;
        
        resultado = (nota1 + nota2 + nota3 /3);
        
        
        if (resultado >=3.3){
            System.out.println("El estudiante aprobo con una nota de " + resultado);
        }
        
        else {
            System.out.println("El estudiante reprobo con una nota de " + resultado); 
        }
        
        
        
        // TODO code application logic here
    }
    
}
