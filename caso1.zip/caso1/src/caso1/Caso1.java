/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso1;

 import java.util.Scanner;
public class Caso1 {
   

    public static void main(String[] args) {

        
        Scanner entrada = new Scanner(System.in);
        
        int edad;
        
        System.out.print("Ingresa tu edad: ");
        edad = entrada.nextInt();
        
        if (edad >= 18) {
            System.out.println("Acceso permitido");
        } else {
            System.out.println("Acceso denegado");
        }
        
        entrada.close();
    }
}
  
