/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso2;

import java.util.Scanner;
public class Caso2 {
    
    public static void main(String[] args) {
    
              Scanner entrada = new Scanner(System.in);

        int numero;

        System.out.print("Ingresa un número entero: ");
        numero = entrada.nextInt();

        if (numero % 2 == 0) {
            System.out.println("El número es par");
        } else {
            System.out.println("El número es impar");
        }

        entrada.close();
       
    }
    
}
